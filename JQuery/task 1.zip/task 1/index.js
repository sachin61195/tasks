$('button').click(function(){
    let input = $('#input').val();
    if(input=="")
        alert("Input field is empty");
    else
    {   let list = document.createElement("li");
        list.textContent = input;
        $("#list").append(list);
        $('#input').val("");
    }
    
});
$('#list').click(function(e){  
       if(e.target.nodeName == 'LI'){
        e.target.remove();
       }
});